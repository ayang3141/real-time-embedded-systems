/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xconfig_rtos__
#define xconfig_rtos__



#endif /* xconfig_rtos__ */ 
