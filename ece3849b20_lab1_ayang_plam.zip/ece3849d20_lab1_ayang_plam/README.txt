### ECE3849 Lab 0 
Authors: Adam Yang, Prudence Lam
